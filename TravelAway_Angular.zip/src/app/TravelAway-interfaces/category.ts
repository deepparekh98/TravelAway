export interface ICategory {
  packageCategoryId: number,
  packageCategoryName: string,
  packagesAvailable:number
}
