export interface IBookpack {
  bookingId: number,
  userId: number,
  emailId: string,
  packageId: number,
  contactNo: number,
  address: string,
  dateOfTravel: Date,
  adultsCount: number,
  childCount: number,
  totalAmount: number,
  subPackageId: number,
  status:string
}
