export interface IUser {
  userId: number,
  emailId: string,
  contactNo: number,
  roldeId: number,
  firstName: string,
  lastName: string,
  userPassword: string,
  gender: string,
  dateOfBirth: Date,
  address:string
}
