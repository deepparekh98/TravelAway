export interface ISubpack {
  subPackageId: number,
  packageId: number,
  packageCategoryId: number,
  packageName: string,
  subPackageName: string,
  imageUrl: string,
  packageCategoryName: string,
  placesToVisit: string,
  description: string,
  daysNight: string,
  pricePerAdult: number,
  pricePerChild:number
}
