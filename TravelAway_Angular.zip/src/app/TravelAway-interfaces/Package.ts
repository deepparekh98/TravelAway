export interface IPackage {
  packageId: number,
  packageCategoryId: number;
  packageName: string,
  imageUrl: string,
  packageCategoryName: string,
  placesToVisit: string,
  description: string,
  daysNight: string,
  pricePerAdult: number,
  pricePerChild: number,
  bookingsCount:number
  }
