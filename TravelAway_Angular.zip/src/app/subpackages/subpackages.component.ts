import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IPackage } from '../TravelAway-interfaces/Package';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';
import { ISubpackage } from '../TravelAway-interfaces/subcategory';
import { IBookpack } from '../TravelAway-interfaces/bookpack';

@Component({
  selector: 'app-subpackages',
  templateUrl: './subpackages.component.html',
  styleUrls: ['./subpackages.component.css']
})
export class SubpackagesComponent implements OnInit {

  constructor(private route: ActivatedRoute, private _Allservices: AllservicesService, private _router: Router) { }
  packageName: string;
  packagenam: string;
  filteredPackages: ISubpackage[];
  ngOnInit() {
    this.packageName = this.route.snapshot.params['packageName'];
    this.packagenam = this.route.snapshot.params['packageNAME'];
    this.getpackages();
  }
  getpackages() {
    console.log(this.packageName);
    this._Allservices.getpackagesbyid(this.packagenam).subscribe(
      res => {
        this.filteredPackages = res;
        console.log("SubPackages returned");
      },
      err => {
        this.filteredPackages = null;
      },
      () => { console.log("Subpackages method");}
    )
  }
  hello(pro: ISubpackage) {
    this._router.navigate(['/bookpackage', pro.subPackageId, pro.pricePerAdult, pro.pricePerChild])
  }
}
