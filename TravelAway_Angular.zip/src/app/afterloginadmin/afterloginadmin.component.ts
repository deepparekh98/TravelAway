import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-afterloginadmin',
  templateUrl: './afterloginadmin.component.html',
  styleUrls: ['./afterloginadmin.component.css']
})
export class AfterloginadminComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
