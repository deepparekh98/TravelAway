import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AfterloginadminComponent } from './afterloginadmin.component';

describe('AfterloginadminComponent', () => {
  let component: AfterloginadminComponent;
  let fixture: ComponentFixture<AfterloginadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AfterloginadminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AfterloginadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
