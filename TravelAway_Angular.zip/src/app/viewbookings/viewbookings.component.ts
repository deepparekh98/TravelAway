import { Component, OnInit } from '@angular/core';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';
import { Router } from '@angular/router';
import { IBookpack } from '../TravelAway-interfaces/bookpack';

@Component({
  selector: 'app-viewbookings',
  templateUrl: './viewbookings.component.html',
  styleUrls: ['./viewbookings.component.css']
})
export class ViewbookingsComponent implements OnInit {
  userName: string;
  books: IBookpack[];
  showMsgDiv: boolean = false;
  constructor(private _Allservices: AllservicesService, private _router: Router) {
    this.userName = sessionStorage.getItem('userName');}

  ngOnInit() {
    this.getbooks()
  }
  getbooks() {
    this._Allservices.bookingBasedOnEmail(this.userName).subscribe(
      res => {
        this.books = res;
        console.log(this.userName);
      },
      err => {
        console.log(err);
        this.showMsgDiv = true;
      },
      () => { console.log('Booking');}
    )
  }
}
