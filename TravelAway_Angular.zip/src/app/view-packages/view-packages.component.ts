import { Component, OnInit } from '@angular/core';
import { IPackage } from '../TravelAway-interfaces/Package';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';
import { ICategory } from '../TravelAway-interfaces/category';
import { Router } from '@angular/router';


@Component({
  selector: 'app-view-packages',
  templateUrl: './view-packages.component.html',
  styleUrls: ['./view-packages.component.css']
})
export class ViewPackagesComponent implements OnInit {
  packages: IPackage[];
  categories: ICategory[];
  showMsgDiv: boolean = false;
  errMsg: string

  filteredPackages: IPackage[];
  searchByPackageName: string;
  searchByCategoryId: string = "0";
  userRole: string;
  userName: string;

  constructor(private _Allservices: AllservicesService, private _router: Router) { }

  //viewdetails() {
  //  this._Allservices.getpackagesbyid().subscribe(
  //    x => {
  //      this.packages = x;

  //    },
  //    y => {

  //      console.log(y);
  //      console.log("Error-Zone");
  //    },
  //    () => { console.log("View Details By Id executed succesfully");}

  //  )
  //}
  hello(pro: IPackage) {
    console.log(pro.packageCategoryId);
    this._router.navigate(['/subpackages', pro.packageCategoryName, pro.packageName])
  }
  getPackages() {
// debugger;
    this._Allservices.getpackages().subscribe(
      responseProductData => {
        this.packages = responseProductData;
        this.filteredPackages = responseProductData;
        this.showMsgDiv = false;
        console.log(responseProductData);

        this.getCategories();
      },
      responseProductError => {
        this.packages = null;
        this.errMsg = responseProductError;
        console.log("This is error",this.errMsg);
        console.log("This is error",'error-zone');
      },
      () => console.log("GetPackages method excuted successfully")
    );

  }

  searchPackage(packageName: string) {
    if (this.searchByCategoryId == "0") {
      this.filteredPackages = this.packages;
    }
    else {
      this.filteredPackages = this.packages.filter(prod => prod.packageCategoryId.toString() == this.searchByCategoryId);
    }
    if (packageName != null || packageName == "") {
      this.searchByPackageName = packageName;
      this.filteredPackages = this.filteredPackages.filter(prod => prod.packageName.toLowerCase().indexOf(packageName.toLowerCase()) >= 0);
    }
    if (this.filteredPackages.length == 0) {
      this.showMsgDiv = true;
    }
    else {
      this.showMsgDiv = false;
    }
  }

  searchPackageByCategory(categoryId: string) {
    if (this.searchByPackageName != null || this.searchByPackageName == "") {
      this.filteredPackages = this.packages.filter(prod => prod.packageName.toLowerCase().indexOf(this.searchByPackageName.toLowerCase()) >= 0);
    }
    else {
      this.filteredPackages = this.packages;
    }
    this.searchByCategoryId = categoryId;
    if (this.searchByCategoryId == "0") {
      this.filteredPackages = this.packages;
    }
    else {
      this.filteredPackages = this.filteredPackages.filter(prod => prod.packageCategoryId.toString() == this.searchByCategoryId);
    }
  }

  getCategories() {

    this._Allservices.getcategories().subscribe(
      responseCategoryData => {
        this.categories = responseCategoryData;
        console.log("Dta", responseCategoryData);
      },
      responseCategoryError => {
        this.categories = null;
        this.errMsg = responseCategoryError;
        console.log("This is error",this.errMsg);
        console.log('error-zone');
      },
      () => console.log("GetCategories method excuted successfully")
    );

  }

  ngOnInit() {
    this.getPackages();
    console.log("ngOnit",this.getPackages());

    if (this.packages == null) {
      this.showMsgDiv = false;
    }
    this.filteredPackages = this.packages;
  }

}
