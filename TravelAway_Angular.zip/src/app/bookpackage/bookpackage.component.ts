import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';
import { NgForm } from '@angular/forms';
import { IBookpack } from '../TravelAway-interfaces/bookpack';

@Component({
  selector: 'app-bookpackage',
  templateUrl: './bookpackage.component.html',
  styleUrls: ['./bookpackage.component.css']
})
export class BookpackageComponent implements OnInit {
  subPackageId: number
  email: string
  pricePerAdult: number
  pricePerChild: number
  total:number
  constructor(private route: ActivatedRoute, private _Allservices: AllservicesService, private _router: Router) {
    this.email = sessionStorage.getItem('userName');
  }
  ngOnInit() {
    this.subPackageId = parseInt(this.route.snapshot.params['subPackageId']);
    this.pricePerAdult = parseInt(this.route.snapshot.params['pricePerAdult']);
    this.pricePerChild = parseInt(this.route.snapshot.params['pricePerChild']);
   }
  bookingPackage(form: NgForm) {
    var book: IBookpack;
    book = {
      contactNo: form.value.cnum,
      address: form.value.add,
      adultsCount: form.value.adult,
      childCount: form.value.child,
      dateOfTravel: form.value.dot,
      emailId: this.email,
      bookingId: 1,
      packageId: 1,
      userId: 1,
      totalAmount: 10,
      status: 'hello',
      subPackageId: this.subPackageId
    }
    this._Allservices.bukpackage(book.bookingId, book.userId, book.emailId, book.packageId, book.contactNo, book.address, book.dateOfTravel, book.adultsCount, book.childCount, book.totalAmount, book.subPackageId, book.status).subscribe(
      res => {
        console.log(res);
        this.total = (form.value.adult * this.pricePerAdult) + (form.value.child * this.pricePerChild);
        console.log(this.total);
        var y = this.total
        sessionStorage.setItem('BookingConfirmation', 'true');
        alert('Booking Successful')
        this._router.navigate(['/payment', res, y])
      },
      err => {
        console.log(err);
      },
      () => {
        console.log("Book Package method");
      }
    )
  }

}
