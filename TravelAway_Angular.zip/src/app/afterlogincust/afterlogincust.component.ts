import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-afterlogincust',
  templateUrl: './afterlogincust.component.html',
  styleUrls: ['./afterlogincust.component.css']
})
export class AfterlogincustComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
