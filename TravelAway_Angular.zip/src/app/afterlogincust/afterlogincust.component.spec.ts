import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AfterlogincustComponent } from './afterlogincust.component';

describe('AfterlogincustComponent', () => {
  let component: AfterlogincustComponent;
  let fixture: ComponentFixture<AfterlogincustComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AfterlogincustComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AfterlogincustComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
