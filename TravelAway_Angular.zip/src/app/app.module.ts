import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ViewPackagesComponent } from './view-packages/view-packages.component';
import { LoginComponent } from './login/login.component';
import { AllservicesService } from './travelAway-services/travelawayservices/allservices.service';
import { HttpClientModule } from '@angular/common/http'
import { routing } from '../app.routing';
import { HomeComponent } from './home/home.component';
import { CommonLayoutComponent } from './common-layout/common-layout.component';
import { RegisteruserComponent } from './registeruser/registeruser.component';
import { CommonadminComponent } from './commonadmin/commonadmin.component';
import { FirstlayoutComponent } from './firstlayout/firstlayout.component';
import { AfterlogincustComponent } from './afterlogincust/afterlogincust.component';
import { AfterloginadminComponent } from './afterloginadmin/afterloginadmin.component';
import { SubpackagesComponent } from './subpackages/subpackages.component';
import { BookpackageComponent } from './bookpackage/bookpackage.component';
import { PaymentComponent } from './payment/payment.component';
import { AfterpaymentComponent } from './afterpayment/afterpayment.component';
import { GenerateReportComponent } from './generate-report/generate-report.component';
import { AddsubpackageComponent } from './addsubpackage/addsubpackage.component';
import { ViewbookingsComponent } from './viewbookings/viewbookings.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewPackagesComponent,
    LoginComponent,
    HomeComponent,
    CommonLayoutComponent,
    RegisteruserComponent,
    CommonadminComponent,
    FirstlayoutComponent,
    AfterlogincustComponent,
    AfterloginadminComponent,
    SubpackagesComponent,
    BookpackageComponent,
    PaymentComponent,
    AfterpaymentComponent,
    GenerateReportComponent,
    AddsubpackageComponent,
    ViewbookingsComponent
  ],
  imports: [
    BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule, routing
  ],
  providers: [AllservicesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
