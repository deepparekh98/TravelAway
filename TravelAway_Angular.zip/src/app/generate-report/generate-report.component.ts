import { Component, OnInit } from '@angular/core';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';
import { ICategory } from '../TravelAway-interfaces/category';
import { IPackage } from '../TravelAway-interfaces/Package';
import { IBookpack } from '../TravelAway-interfaces/bookpack';

@Component({
  selector: 'app-generate-report',
  templateUrl: './generate-report.component.html',
  styleUrls: ['./generate-report.component.css']
})
export class GenerateReportComponent implements OnInit {
  categories: ICategory[];
  packages: IPackage[];
  bookings: IBookpack[];
  userRole: string;
  customerLayout: boolean;
  commonLayout: boolean;
  errMsg: string;
  status: boolean;
  showDivMsg: boolean = false;
  constructor(private _AllServicesService: AllservicesService) {
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "1") {
      this.customerLayout = true;
    }
    else {
      this.commonLayout = true;
    }
  }

  getPackageCategories(x: string) {
    if (x == "1") {
      this.showDivMsg = false;
      this._AllServicesService.getcategories().subscribe(
        responseCategoryData => this.categories = responseCategoryData,
        responseCategoryError => {
          this.categories = null;
          this.errMsg = responseCategoryError;
          console.log(this.errMsg);
        },
        () => console.log("GetProductCategoies method excuted successfully")
      );
    }
    else {
      this.categories = null;
    }
    if (x == "2") {
      this.showDivMsg = false;
      this._AllServicesService.getpackages().subscribe(
        responseCategoryData => this.packages = responseCategoryData,
        responseCategoryError => {
          this.categories = null;
          this.errMsg = responseCategoryError;
          console.log(this.errMsg);
        },
        () => console.log("GetProductCategoies method excuted successfully")
      );
    }
    else {
      this.packages = null;
    }
    if (x == "3") {
      this.status = true;
    }
    else {
      this.status = false;
    }
  }
  bookingBasedOnMonth(x: string) {
    this._AllServicesService.bookingBasedOnMonths(x).subscribe(
      responseCategoryData => {
        this.bookings = responseCategoryData;
        if (this.bookings.length == 0) {
          this.showDivMsg = true;
        }
        else{
          this.showDivMsg = false;
        }
      },
      responseCategoryError => {
        this.bookings = null;
        this.errMsg = responseCategoryError;
        console.log(this.errMsg);
      },
      () => console.log("GetProductCategoies method excuted successfully")
    );
  }

  ngOnInit() {
  }

}
