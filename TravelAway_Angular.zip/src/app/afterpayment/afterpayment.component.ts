
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-afterpayment',
  templateUrl: './afterpayment.component.html',
  styleUrls: ['./afterpayment.component.css']
})
export class AfterpaymentComponent implements OnInit {
  x: string;
  constructor(private route:Router) {
    this.x = sessionStorage.getItem('BookingConfirmation');
    sessionStorage.setItem('BookBack', 'false');
    if (this.x == null) {
      this.route.navigate['/home'];
    }

  }

  ngOnInit() {
  }

}
