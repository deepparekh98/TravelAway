import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  status: number;
  errorMsg: any;
  showDiv: boolean=false;
  msg: string;

  constructor(private _allservices: AllservicesService,private _router:Router) { }
  submitLoginForm(form: NgForm) {
    this._allservices.validateuser(form.value.email, form.value.password).subscribe(
      responseLoginStatus => {
        this.status = responseLoginStatus;
        console.log(this.status);
        if (responseLoginStatus == 0) {
          this.showDiv = true;
          this.msg = "Invalid Credentials";
        }
        else {
          sessionStorage.setItem('userName', form.value.email);
          sessionStorage.setItem('userRole', (this.status).toString());
          this._router.navigate(['/home'])
          //if (responseLoginStatus == 2) {
          //  this._router.navigate(['/afterlogincust']);
          //}
          //else {
          //  this._router.navigate(['/afterloginadmin']);
          //}
        }
        //if (this.status!= 0) {
        //  sessionStorage.setItem('userName', form.value.email);
        //  sessionStorage.setItem('userRole', this.status);
        //}
        //else {
        //  this.showDiv = true;
        //  this.msg = this.status + ". Try again with valid credentials.";
        //}
      },
      responseLoginError => {
        this.errorMsg = responseLoginError;
      },
      () => console.log("SubmitLoginForm method executed successfully")
    );
  }
  ngOnInit() {
  }

}
