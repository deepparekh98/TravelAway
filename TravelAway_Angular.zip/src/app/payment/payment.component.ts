import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {

  res: number;
  y: number;
  constructor(private route: ActivatedRoute, private _Allservices: AllservicesService, private _router: Router) { }

  ngOnInit() {
    this.res = parseInt(this.route.snapshot.params['res']);
    this.y = parseInt(this.route.snapshot.params['y']);
  }
  hello() {
    this._Allservices.uppdate((this.res).toString()).subscribe(
      res => {
        console.log(res);
        sessionStorage.removeItem('BookingConfirmation');
        this._router.navigate(['/afterpayment'])
      },
      err => {
        console.log(err);
      },
      () => {
        console.log('Value updated successfully');
      }
    )
  }
}
