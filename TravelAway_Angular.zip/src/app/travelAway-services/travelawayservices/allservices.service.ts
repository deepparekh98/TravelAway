import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IPackage } from '../../TravelAway-interfaces/Package';
import { ICategory } from '../../TravelAway-interfaces/category';
import { IUser } from '../../TravelAway-interfaces/user';
import { ISubpackage } from '../../TravelAway-interfaces/subcategory';
import { Data } from '@angular/router';
import { IBookpack } from '../../TravelAway-interfaces/bookpack';
import { ISubpack } from '../../TravelAway-interfaces/subpack';

@Injectable({
  providedIn: 'root'
})
export class AllservicesService {
  packages: IPackage[]
  constructor(private http: HttpClient) { }
  getpackages(): Observable<IPackage[]>{
    // debugger;
    let temp = this.http.get<IPackage[]>('https://travelaway.azurewebsites.net/api/TravelAway/GetPackages');
    console.log("service", temp);
    return temp;
  }
  getpackagesbyid(id: string): Observable<ISubpackage[]> {
    let temp = this.http.get<ISubpackage[]>('https://travelaway.azurewebsites.net/api/TravelAway/GetPackagesById?name=' +id );
    return temp;
  }
  uppdate(id: string): Observable<boolean> {
    let temp = this.http.put<boolean>('https://travelaway.azurewebsites.net/api/TravelAway/updatingStatus?x=' + id, {});
    return temp;
  }
  bookingBasedOnMonths(s: string): Observable<IBookpack[]> {
    let temp = this.http.get<IBookpack[]>('https://travelaway.azurewebsites.net/api/TravelAway/GetBookingsBoMonth?i=' + s);
    return temp;
  }
  bookingBasedOnEmail(s: string): Observable<IBookpack[]> {
    let temp = this.http.get<IBookpack[]>('https://travelaway.azurewebsites.net/api/TravelAway/GetBookingbymailid?mail=' + s);
    return temp;
  }
  getcategories(): Observable<ICategory[]> {
    let temp = this.http.get<ICategory[]>('https://travelaway.azurewebsites.net/api/TravelAway/GetPackageCategories');
    console.log("Dta",temp);
    return temp;
  }
  validateuser(id: string, pwd: string): Observable<number> {
    var dates: Date;
    var userObj: IUser;
    userObj = { emailId: id, userPassword: pwd, userId: 1, roldeId: 1, contactNo: 28555, firstName: 'har', lastName: 'sha', gender: 'M', dateOfBirth:dates, address:'hello' };
    let temp = this.http.post<number>('https://travelaway.azurewebsites.net/api/TravelAway/validateUser', userObj);
    return temp;
  }
  addUser(userid: number, email: string, cno: number, first: string, last: string, userpwd: string, roleid: number, gendr: string, dob: Date, addre: string,): Observable<boolean> {
    var Userobj: IUser;
    Userobj = {
      userId: userid,
      emailId: email,
      contactNo: cno,
      firstName: first,
      lastName: last,
      userPassword: userpwd,
      roldeId: roleid,
      gender: gendr,
      dateOfBirth: dob,
      address: addre
    }
    let temp = this.http.post<boolean>('https://travelaway.azurewebsites.net/api/TravelAway/AddUser', Userobj);
    return temp;
  }

  addPack(spid: number, pid: number, pcid: number, pn: string, spn: string, imgu: string, pcn: string, ptv: string, desc: string, day: string, ppa: number, ppc: number): Observable<boolean> {
    var obj: ISubpack;
    obj = {
      subPackageId: spid,
      packageId: pid,
      packageCategoryId: pcid,
      packageName: pn,
      subPackageName: spn,
      imageUrl: imgu,
      packageCategoryName: pcn,
      placesToVisit: ptv,
      description: desc,
      daysNight: day,
      pricePerAdult: ppa,
      pricePerChild:ppc
    }
    let temp = this.http.post<boolean>('https://travelaway.azurewebsites.net/api/TravelAway/AddSubPackageMethod', obj);
    return temp;
  }


  bukpackage(bookingid: number, userid: number, emailid: string, packageid: number, cnum: number, addre: string, dot: Date, adultscount: number, childcount: number, totalamount: number, subpackageid: number, statu: string): Observable<number> {
    var BookObj: IBookpack;
    BookObj = {
      bookingId: bookingid,
      userId: userid,
      emailId: emailid,
      packageId: packageid,
      contactNo: cnum,
      address: addre,
      dateOfTravel: dot,
      adultsCount: adultscount,
      childCount: childcount,
      totalAmount: totalamount,
      subPackageId: subpackageid,
      status: statu
    }
    let temp = this.http.post<number>('https://travelaway.azurewebsites.net/api/TravelAway/BookPackageMethod', BookObj);
    return temp;
  }
}
