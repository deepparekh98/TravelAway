import { TestBed } from '@angular/core/testing';

import { AllservicesService } from './allservices.service';

describe('AllservicesService', () => {
  let service: AllservicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AllservicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
