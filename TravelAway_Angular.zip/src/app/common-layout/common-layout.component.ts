import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-common-layout',
  templateUrl: './common-layout.component.html',
  styleUrls: ['./common-layout.component.css']
})
export class CommonLayoutComponent implements OnInit {
  userRole: string;
  constructor(private _router: Router) {
    this.userRole = sessionStorage.getItem('userRole');}

  ngOnInit() {
  }
  logout() {
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('BookBack');
    this._router.navigate(['']);
  }

}
