import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FirstlayoutComponent } from './firstlayout.component';

describe('FirstlayoutComponent', () => {
  let component: FirstlayoutComponent;
  let fixture: ComponentFixture<FirstlayoutComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FirstlayoutComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FirstlayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
