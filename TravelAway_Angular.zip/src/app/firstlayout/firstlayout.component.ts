import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-firstlayout',
  templateUrl: './firstlayout.component.html',
  styleUrls: ['./firstlayout.component.css']
})
export class FirstlayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  message() {
    alert('Click on login and login with correct credentials')
  }
}
