import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  userRole: string;
  customerLayout: boolean = false;
  commonLayout: boolean = false;
  cit: boolean = false;
  constructor() {
    sessionStorage.removeItem('BookBack');
    this.userRole = sessionStorage.getItem('userRole');
    if (this.userRole == "1") {
      this.customerLayout = true;
      this.cit = false;
    }
    else if (this.userRole == "2") {
      this.commonLayout = true;
      this.cit = false;
    }
    else {
      this.cit = true;
    }
  }

  ngOnInit() {
  }

}
