import { Component, OnInit } from '@angular/core';
import { IUser } from '../TravelAway-interfaces/user';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-registeruser',
  templateUrl: './registeruser.component.html',
  styleUrls: ['./registeruser.component.css']
})
export class RegisteruserComponent implements OnInit {
  constructor(private _allservices: AllservicesService, private _router: Router) { }

  ngOnInit() {
  }
  submitRegisterForm(form: NgForm) {
    var userObj: IUser;
    userObj = {
      emailId: form.value.email,
      userPassword: form.value.password,
      gender: form.value.gender,
      roldeId: 2,
      userId: 10,
      firstName: form.value.fname,
      lastName: form.value.lname,
      contactNo: form.value.cnum,
      dateOfBirth: form.value.dob,
      address: form.value.address
    }
    this._allservices.addUser(userObj.userId, userObj.emailId, userObj.contactNo, userObj.firstName, userObj.lastName, userObj.userPassword, userObj.roldeId, userObj.gender, userObj.dateOfBirth, userObj.address).subscribe(
      res => {
        console.log(res);
        if (res) {
          alert("User Succesfully Added")
          this._router.navigate(['/login'])
        }
        else {
          alert("Error SigningUp")
        }
      },
      err => { console.log(err); },
      () => { console.log("Add new user component"); }

    )
   }

}
