import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddsubpackageComponent } from './addsubpackage.component';

describe('AddsubpackageComponent', () => {
  let component: AddsubpackageComponent;
  let fixture: ComponentFixture<AddsubpackageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddsubpackageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddsubpackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
