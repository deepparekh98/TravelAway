import { Component, OnInit } from '@angular/core';
import { AllservicesService } from '../travelAway-services/travelawayservices/allservices.service';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { ISubpack } from '../TravelAway-interfaces/subpack';

@Component({
  selector: 'app-addsubpackage',
  templateUrl: './addsubpackage.component.html',
  styleUrls: ['./addsubpackage.component.css']
})
export class AddsubpackageComponent implements OnInit {

  constructor(private _allservices: AllservicesService, private _router: Router) { }

  ngOnInit() {
  }
  addsubpack(form: NgForm) {
    var obj: ISubpack;
    obj = {
      subPackageId: 101,
      packageId: form.value.pid,
      packageCategoryId: form.value.pcid,
      packageName: form.value.pn,
      subPackageName: form.value.spn,
      imageUrl: form.value.imgu,
      packageCategoryName: form.value.pcn,
      placesToVisit: form.value.ptv,
      description: form.value.desc,
      daysNight: form.value.dn,
      pricePerAdult: form.value.ppa,
      pricePerChild: form.value.ppc
    }
    this._allservices.addPack(obj.packageId, obj.packageId, obj.packageCategoryId, obj.packageName, obj.subPackageName, obj.imageUrl, obj.packageCategoryName, obj.placesToVisit, obj.description, obj.daysNight, obj.pricePerAdult, obj.pricePerChild).subscribe(
      res => {
        console.log(res);
      },
      err => {
        console.log(err);
      },
      () => { console.log('Add Packages Method');}
    )
  }

}
