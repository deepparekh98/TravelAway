import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonadminComponent } from './commonadmin.component';

describe('CommonadminComponent', () => {
  let component: CommonadminComponent;
  let fixture: ComponentFixture<CommonadminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CommonadminComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CommonadminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
