import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-commonadmin',
  templateUrl: './commonadmin.component.html',
  styleUrls: ['./commonadmin.component.css']
})
export class CommonadminComponent implements OnInit {

  constructor(private _router: Router) { }

  ngOnInit() {
  }
  logout() {
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('userRole');
    this._router.navigate(['']);
  }
  message() {
    alert('Coming Soon...')
  }
}
