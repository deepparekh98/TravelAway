import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { LoginComponent } from './app/login/login.component';
import { ViewPackagesComponent } from './app/view-packages/view-packages.component';
import { HomeComponent } from './app/home/home.component';
import { RegisteruserComponent } from './app/registeruser/registeruser.component';
import { FirstlayoutComponent } from './app/firstlayout/firstlayout.component';
import { CommonadminComponent } from './app/commonadmin/commonadmin.component';
import { AfterloginadminComponent } from './app/afterloginadmin/afterloginadmin.component';
import { AfterlogincustComponent } from './app/afterlogincust/afterlogincust.component';
import { AuthGuardService } from './app/travelAway-services/auth-service/auth-guard.service';
import { SubpackagesComponent } from './app/subpackages/subpackages.component';
import { BookpackageComponent } from './app/bookpackage/bookpackage.component';
import { PaymentComponent } from './app/payment/payment.component';
import { AfterpaymentComponent } from './app/afterpayment/afterpayment.component';
import { GenerateReportComponent } from './app/generate-report/generate-report.component';
import { AddsubpackageComponent } from './app/addsubpackage/addsubpackage.component';
import { ViewbookingsComponent } from './app/viewbookings/viewbookings.component';
const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'firstlayout', component: FirstlayoutComponent },
  { path: 'viewbookings', component: ViewbookingsComponent },
  { path: 'subpackages', component: SubpackagesComponent },
  { path: 'addsubpackage', component: AddsubpackageComponent },
  { path: 'subpackages/:packageName/:packageNAME', component: SubpackagesComponent, canActivate: [AuthGuardService] },
  { path: 'generatereport', component: GenerateReportComponent, canActivate: [AuthGuardService] },
  { path: 'bookpackage/:subPackageId/:pricePerAdult/:pricePerChild', component: BookpackageComponent, canActivate: [AuthGuardService] },
  { path: 'payment/:res/:y', component: PaymentComponent, canActivate: [AuthGuardService] },
  { path: 'commonadmin', component: CommonadminComponent },
  { path: 'viewpackages', component: ViewPackagesComponent, canActivate: [AuthGuardService] },
  { path: 'afterpayment', component: AfterpaymentComponent, canActivate: [AuthGuardService] },
  { path: 'registeruser', component: RegisteruserComponent },
  { path: 'afterloginadmin', component: AfterloginadminComponent },
  { path: 'afterlogincust', component: AfterlogincustComponent },
  { path: 'commonadmin', component: CommonadminComponent, canActivate: [AuthGuardService] },
  { path: '**', component: AfterloginadminComponent }
];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
