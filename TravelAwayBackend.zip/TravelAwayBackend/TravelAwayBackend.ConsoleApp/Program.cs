﻿using System;
using TravelAwayBackend.DataAccessLayer;
using TravelAwayBackend.DataAccessLayer.Models;
using System.Collections.Generic;

namespace TravelAwayBackend.ConsoleApp
{
    public class Program
    {
        static void Main(string[] args)
        {
            TravelAwayRepository repository = new TravelAwayRepository();

            //var x = repository.UpdateStatus(55);
            //Console.WriteLine(x);
            // var lst = repository.GetBookingsBoDate(09);
            //string s = "2019-08-05";
            //DateTime date = DateTime.ParseExact(s, "yyyy/MM/dd", null);
            //Users x = new Users();
            //x.UserId = 1;
            //x.EmailId = "HeyHellosssssss@gmail.com";
            //x.ContactNo = 9177804304;
            //x.RoleId = 1;
            //x.FirstName = "HHelloss";
            //x.LastName = "BByeess";
            //x.UserPassword = "Byes@1233";
            //x.Gender = "F";
            //x.DateOfBirth = date;
            //x.Address = "parkss";
            //bool b = repository.RegisterUser(x);
            //Console.WriteLine(b);

            // var x = repository.GetAllPackages();
            // Console.WriteLine(x);
            //var lst = repository.GetAllPackagesById("Adventure");
            //var lst = repository.GetAllBookings();
            //string s = "2020-12-05";
            //DateTime date = DateTime.ParseExact(s, "yyyy/MM/dd", null);
            //BookPackage x = new BookPackage();
            //x.SubPackageId = 1001;
            //x.ContactNo = 784512745;
            //x.AdultsCount = 2;
            //x.ChildCount = 2;
            //x.DateOfTravel = date;
            //x.EmailId = "harry@gmail.com";
            //x.BookingId = 101;
            //x.PackageId = 10;
            //x.UserId = 1;
            //x.TotalAmount = 100;
            //x.Status = "hello";
            //x.Address = "mys";

            //var lst = repository.GetAllBookingsByMail("harry@gmail.com");
            ////Console.WriteLine(lst);
            //if (lst == null)
            //{
            //}
            //else
            //{

            //    foreach (var x in lst)
            //    {

            //        Console.WriteLine(x.BookingId);
            //    }
            //}

            var y = repository.GetAllPackages();
            List<PackageDetails> packageList = repository.GetAllPackages();
            Console.WriteLine("--------------------------");
            Console.WriteLine("yok");
            Console.WriteLine("--------------------------");
            //if (packageList != null)
            //{
            foreach (var package in y)
            {
                //Models.PackageDetail packageObj = _mapper.Map<Models.PackageDetail>(package);
                //lst.Add(packageObj);

                Console.WriteLine("YOK", package.PackageId, package.PackageName);
            }
            //}
        }
    }

}
