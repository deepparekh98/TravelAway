﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using TravelAwayBackend.DataAccessLayer.Models;

namespace TravelAwayBackend.WebServices
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<PackageDetails, Models.PackageDetails>();
            CreateMap<SubPackageDetails, Models.SubPackageDetails>();
            CreateMap<Models.SubPackageDetails, SubPackageDetails>();
            CreateMap<PackageCategory, Models.PackageCategory>();
            //CreateMap<Models.PackageDetails, PackageDetails>();
            CreateMap<Models.Users, Users>();
            CreateMap<Users, Models.Users>();
            CreateMap<Models.BookPackage, BookPackage>();
            CreateMap<BookPackage, Models.BookPackage>();
        }
    }
}