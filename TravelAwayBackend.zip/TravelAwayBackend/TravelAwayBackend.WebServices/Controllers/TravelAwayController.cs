﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using TravelAwayBackend.DataAccessLayer;
using TravelAwayBackend.DataAccessLayer.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace TravelAwayBackend.WebServices.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class TravelAwayController : ControllerBase
    {
        
        private readonly IMapper _mapper;
        private readonly TravelAwayRepository _repository;
        public TravelAwayController(TravelAwayRepository repository,IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        // GET: api/<TravelAwayController>
        [HttpGet]
        public JsonResult GetPackages()
        {
            List<Models.PackageDetails> lst = new List<Models.PackageDetails>();
            try
            {
                List<PackageDetails> packageList = _repository.GetAllPackages();
                if (packageList != null)
                {
                    foreach (var package in packageList)
                    {
                        Models.PackageDetails packageObj = _mapper.Map<Models.PackageDetails>(package);
                        lst.Add(packageObj);
                    }
                }
            }
            catch (Exception)
            {

                lst = null;
            }
            return new JsonResult(lst);
        }
        [HttpGet]
        public JsonResult GetAllUserDetails()
        {
            List<Models.Users> lst = new List<Models.Users>();
            try
            {
                List<Users> l = _repository.GetAllUsers();
                if(l!=null)
                {
                    foreach(var x in l)
                    {
                        Models.Users a = _mapper.Map<Models.Users>(x);
                        lst.Add(a);
                    }
                }

            }
            catch (Exception)
            {
                lst = null;
            }
            return new JsonResult(lst);
        }

        [HttpGet]
        public JsonResult GetBookings()
        {
            List<Models.BookPackage> lst = new List<Models.BookPackage>();
            try
            {
                List<BookPackage> bklst = _repository.GetAllBookings();
                if(bklst!=null)
                {
                    foreach (var x in bklst)
                    {
                        Models.BookPackage BookObj = _mapper.Map<Models.BookPackage>(x);
                        lst.Add(BookObj);
                    }
                }
            }
            catch (Exception)
            {
                lst = null;
            }
            return new JsonResult(lst);

        }
       
        [HttpGet]
        public JsonResult GetBookingsBoMonth(string i)
        {
            List<Models.BookPackage> lst = new List<Models.BookPackage>();
            try
            {
                List<BookPackage> bklst = _repository.GetBookingsBoDate(Convert.ToInt32(i));
                if (bklst != null)
                {
                    foreach (var x in bklst)
                    {
                        Models.BookPackage BookObj = _mapper.Map<Models.BookPackage>(x);
                        lst.Add(BookObj);
                    }
                }
            }
            catch (Exception)
            {
                lst = null;
            }
            return new JsonResult(lst);
        }

        [HttpGet]
        public JsonResult GetPackagesById(string name)
        {
            List<Models.SubPackageDetails> lst = new List<Models.SubPackageDetails>();
            try
            {
                List<SubPackageDetails> packageList = _repository.GetAllPackagesById(name);
                if (packageList != null)
                {
                    foreach (var package in packageList)
                    {
                        Models.SubPackageDetails packageObj = _mapper.Map<Models.SubPackageDetails>(package);
                        lst.Add(packageObj);
                    }
                }
            }
            catch (Exception)
            {

                lst = null;
            }
            return new JsonResult(lst);
        }

        [HttpGet]
        public JsonResult GetBookingbymailid(string mail)
        {
            List<Models.BookPackage> lst = new List<Models.BookPackage>();
            try
            {
                List<BookPackage> l = _repository.GetAllBookingsByMail(mail);
                if(l!=null)
                {
                    foreach(var x in l)
                    {
                        Models.BookPackage book = _mapper.Map<Models.BookPackage>(x);
                        lst.Add(book);
                    }
                }

            }
            catch (Exception)
            {
                lst = null;
            }
            return new JsonResult(lst);
        }
       

        [HttpGet]
        public JsonResult GetPackageCategories()
        {
            List<Models.PackageCategory> lst = new List<Models.PackageCategory>();
            try
            {
                List<PackageCategory> packageCategoryList = _repository.GetAllPackageCategories();
                if (packageCategoryList != null)
                {
                    foreach (var package in packageCategoryList)
                    {
                        Models.PackageCategory packageObj = _mapper.Map<Models.PackageCategory>(package);
                        lst.Add(packageObj);
                    }
                }
            }
            catch (Exception)
            {

                lst = null;
            }
            return new JsonResult(lst);
        }

        // GET api/<TravelAwayController>/5
        [HttpPost]
        public JsonResult ValidateUser(Models.Users userObj)
        {
            int userRole = 0;
            try
            {
                userRole = _repository.ValidateUser(userObj.EmailId, userObj.UserPassword);
            }
            catch (Exception)
            {
                userRole = 0;
            }
            return new JsonResult(userRole);
        }

        [HttpPost]
        public JsonResult AddSubPackageMethod(Models.SubPackageDetails obj)
        {
            bool status = false;
            try
            {
               status= _repository.AddSubPackage(_mapper.Map<SubPackageDetails>(obj));
            }
            catch (Exception)
            {
                status = false;
            }
            return new JsonResult(status);
            
        }

        [HttpPost]
        public JsonResult BookPackageMethod(Models.BookPackage bookObj)
        {
            int bookId = 0;
            try
            {
                bookId = _repository.BookPackage(_mapper.Map<BookPackage>(bookObj));
            }
            catch (Exception)
            {
                bookId = 0;
            }
            return new JsonResult(bookId);
        }



        // POST api/<TravelAwayController>
        [HttpPost]
        public JsonResult AddUser(Models.Users _user)
        {
            bool status = false;
           // string status = null;
           // int status = 0;
            try
            {
                status = _repository.RegisterUser(_mapper.Map<Users>(_user));
            }
            catch (Exception ex)
            {
                status = false;
            }
            return new JsonResult(status);
        }

        // PUT api/<TravelAwayController>/5
        [HttpPut]
        public JsonResult updatingStatus(string x)
        {
            bool status = false;
            try
            {
                status = _repository.UpdateStatus(Convert.ToInt32(x));
            }
            catch (Exception)
            {
                status = false;
            }
            return new JsonResult(status);
        }

        // DELETE api/<TravelAwayController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}