﻿using System;
using System.Collections.Generic;

namespace TravelAwayBackend.WebServices.Models
{
    public partial class PackageCategory
    {
        public PackageCategory()
        {
            Bookings = new HashSet<Bookings>();
            PackageDetails = new HashSet<PackageDetails>();
            SubPackageDetailsPackageCategory = new HashSet<SubPackageDetails>();
            SubPackageDetailsPackageCategoryNameNavigation = new HashSet<SubPackageDetails>();
        }

        public byte PackageCategoryId { get; set; }
        public string PackageCategoryName { get; set; }
        public short PackagesAvailable { get; set; }

        public virtual ICollection<Bookings> Bookings { get; set; }
        public virtual ICollection<PackageDetails> PackageDetails { get; set; }
        public virtual ICollection<SubPackageDetails> SubPackageDetailsPackageCategory { get; set; }
        public virtual ICollection<SubPackageDetails> SubPackageDetailsPackageCategoryNameNavigation { get; set; }
    }
}
