﻿using System;
using System.Collections.Generic;

namespace TravelAwayBackend.WebServices.Models
{
    public partial class PackageDetails
    {
        public PackageDetails()
        {
            BookPackage = new HashSet<BookPackage>();
            Bookings = new HashSet<Bookings>();
            SubPackageDetailsPackage = new HashSet<SubPackageDetails>();
            SubPackageDetailsPackageNameNavigation = new HashSet<SubPackageDetails>();
        }

        public byte PackageId { get; set; }
        public byte? PackageCategoryId { get; set; }
        public string PackageName { get; set; }
        public string ImageUrl { get; set; }
        public string PackageCategoryName { get; set; }
        public string PlacesToVisit { get; set; }
        public string Description { get; set; }
        public string DaysNight { get; set; }
        public decimal PricePerAdult { get; set; }
        public decimal PricePerChild { get; set; }
        public int? BookingsCount { get; set; }

        public virtual PackageCategory PackageCategory { get; set; }
        public virtual ICollection<BookPackage> BookPackage { get; set; }
        public virtual ICollection<Bookings> Bookings { get; set; }
        public virtual ICollection<SubPackageDetails> SubPackageDetailsPackage { get; set; }
        public virtual ICollection<SubPackageDetails> SubPackageDetailsPackageNameNavigation { get; set; }
    }
}
