﻿using System;
using System.Collections.Generic;

namespace TravelAwayBackend.DataAccessLayer.Models
{
    public partial class Bookings
    {
        public int? UserId { get; set; }
        public long? BookingId { get; set; }
        public byte? PackageCategoryId { get; set; }
        public byte? PackageId { get; set; }

        public virtual BookPackage Booking { get; set; }
        public virtual PackageDetails Package { get; set; }
        public virtual PackageCategory PackageCategory { get; set; }
        public virtual Users User { get; set; }
    }
}
