﻿using System;
using System.Collections.Generic;

namespace TravelAwayBackend.DataAccessLayer.Models
{
    public partial class Users
    {
        public Users()
        {
            BookPackageEmail = new HashSet<BookPackage>();
            BookPackageUser = new HashSet<BookPackage>();
            Bookings = new HashSet<Bookings>();
        }

        public int UserId { get; set; }
        public string EmailId { get; set; }
        public decimal ContactNo { get; set; }
        public byte? RoleId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserPassword { get; set; }
        public string Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }

        public virtual Roles Role { get; set; }
        public virtual ICollection<BookPackage> BookPackageEmail { get; set; }
        public virtual ICollection<BookPackage> BookPackageUser { get; set; }
        public virtual ICollection<Bookings> Bookings { get; set; }
    }
}
