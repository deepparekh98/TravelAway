﻿using System;
using System.Collections.Generic;

namespace TravelAwayBackend.DataAccessLayer.Models
{
    public partial class SubPackageDetails
    {
        public SubPackageDetails()
        {
            BookPackage = new HashSet<BookPackage>();
        }

        public int SubPackageId { get; set; }
        public byte? PackageId { get; set; }
        public byte? PackageCategoryId { get; set; }
        public string PackageName { get; set; }
        public string SubPackageName { get; set; }
        public string ImageUrl { get; set; }
        public string PackageCategoryName { get; set; }
        public string PlacesToVisit { get; set; }
        public string Description { get; set; }
        public string DaysNight { get; set; }
        public decimal PricePerAdult { get; set; }
        public decimal PricePerChild { get; set; }

        public virtual PackageDetails Package { get; set; }
        public virtual PackageCategory PackageCategory { get; set; }
        public virtual PackageCategory PackageCategoryNameNavigation { get; set; }
        public virtual PackageDetails PackageNameNavigation { get; set; }
        public virtual ICollection<BookPackage> BookPackage { get; set; }
    }
}
