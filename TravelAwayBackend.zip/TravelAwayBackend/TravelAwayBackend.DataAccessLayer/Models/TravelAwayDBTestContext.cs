﻿using System;
using System.IO;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.Extensions.Configuration;

namespace TravelAwayBackend.DataAccessLayer.Models
{
    public partial class TravelAwayDBTestContext : DbContext
    {
        public TravelAwayDBTestContext()
        {
        }

        public TravelAwayDBTestContext(DbContextOptions<TravelAwayDBTestContext> options)
            : base(options)
        {
        }

        public virtual DbSet<BookPackage> BookPackage { get; set; }
        public virtual DbSet<Bookings> Bookings { get; set; }
        public virtual DbSet<PackageCategory> PackageCategory { get; set; }
        public virtual DbSet<PackageDetails> PackageDetails { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<SubPackageDetails> SubPackageDetails { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var builder = new ConfigurationBuilder()
                          .SetBasePath(Directory.GetCurrentDirectory())
                          .AddJsonFile("appsettings.json");
            var config = builder.Build();
            var connectionString = config.GetConnectionString("TravelAwayDBConnectionString");
            if (!optionsBuilder.IsConfigured)
            {

                optionsBuilder.UseSqlServer(connectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<BookPackage>(entity =>
            {
                entity.HasKey(e => e.BookingId)
                    .HasName("pk_BookingId");

                entity.Property(e => e.BookingId).ValueGeneratedNever();

                entity.Property(e => e.Address)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ContactNo).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.DateOfTravel).HasColumnType("date");

                entity.Property(e => e.EmailId)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Status)
                    .HasMaxLength(100)
                    .IsUnicode(false);

                entity.Property(e => e.TotalAmount).HasColumnType("numeric(15, 0)");

                entity.HasOne(d => d.Email)
                    .WithMany(p => p.BookPackageEmail)
                    .HasPrincipalKey(p => p.EmailId)
                    .HasForeignKey(d => d.EmailId)
                    .HasConstraintName("fk_EmaiD");

                entity.HasOne(d => d.Package)
                    .WithMany(p => p.BookPackage)
                    .HasForeignKey(d => d.PackageId)
                    .HasConstraintName("fk_PackageId");

                entity.HasOne(d => d.SubPackage)
                    .WithMany(p => p.BookPackage)
                    .HasForeignKey(d => d.SubPackageId)
                    .HasConstraintName("fk_spId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.BookPackageUser)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("fk_UserId");
            });

            modelBuilder.Entity<Bookings>(entity =>
            {
                entity.HasKey(e => new { e.BookingId, e.PackageCategoryId, e.PackageId, e.UserId });

                entity.HasOne(d => d.Booking)
                    .WithMany(p => p.Bookings)
                    .HasForeignKey(d => d.BookingId)
                    .HasConstraintName("fk_BookingId");

                entity.HasOne(d => d.PackageCategory)
                    .WithMany(p => p.Bookings)
                    .HasForeignKey(d => d.PackageCategoryId)
                    .HasConstraintName("fk_PackageCategoryIds");

                entity.HasOne(d => d.Package)
                    .WithMany(p => p.Bookings)
                    .HasForeignKey(d => d.PackageId)
                    .HasConstraintName("fk_PackageIds");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Bookings)
                    .HasForeignKey(d => d.UserId)
                    .HasConstraintName("fk_CustomerId");
            });

            modelBuilder.Entity<PackageCategory>(entity =>
            {
                entity.HasIndex(e => e.PackageCategoryName)
                    .HasName("uq_CategoryName")
                    .IsUnique();

                entity.Property(e => e.PackageCategoryName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<PackageDetails>(entity =>
            {
                entity.HasKey(e => e.PackageId)
                    .HasName("pk_PackageId");

                entity.HasIndex(e => e.PackageName)
                    .HasName("uq_PackageName")
                    .IsUnique();

                entity.Property(e => e.DaysNight)
                    .HasColumnName("Days/Night")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.ImageUrl)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.PackageCategoryName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PackageName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlacesToVisit)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.PricePerAdult).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.PricePerChild).HasColumnType("numeric(10, 0)");

                entity.HasOne(d => d.PackageCategory)
                    .WithMany(p => p.PackageDetails)
                    .HasForeignKey(d => d.PackageCategoryId)
                    .HasConstraintName("fk_PackageCategoryId");
            });

            modelBuilder.Entity<Roles>(entity =>
            {
                entity.HasKey(e => e.RoleId)
                    .HasName("pk_RoleId");

                entity.HasIndex(e => e.RoleName)
                    .HasName("uq_RoleName")
                    .IsUnique();

                entity.Property(e => e.RoleName)
                    .HasMaxLength(20)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<SubPackageDetails>(entity =>
            {
                entity.HasKey(e => e.SubPackageId)
                    .HasName("pk_SubPackageId");

                entity.HasIndex(e => e.SubPackageName)
                    .HasName("uq_SubPackageName")
                    .IsUnique();

                entity.Property(e => e.SubPackageId).ValueGeneratedNever();

                entity.Property(e => e.DaysNight)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Description)
                    .HasMaxLength(1000)
                    .IsUnicode(false);

                entity.Property(e => e.ImageUrl)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.PackageCategoryName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.PackageName)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.PlacesToVisit)
                    .HasMaxLength(300)
                    .IsUnicode(false);

                entity.Property(e => e.PricePerAdult).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.PricePerChild).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.SubPackageName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.HasOne(d => d.PackageCategory)
                    .WithMany(p => p.SubPackageDetailsPackageCategory)
                    .HasForeignKey(d => d.PackageCategoryId)
                    .HasConstraintName("fkey_PackageCategoryId");

                entity.HasOne(d => d.PackageCategoryNameNavigation)
                    .WithMany(p => p.SubPackageDetailsPackageCategoryNameNavigation)
                    .HasPrincipalKey(p => p.PackageCategoryName)
                    .HasForeignKey(d => d.PackageCategoryName)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("fkey_PackageCategoryName");

                entity.HasOne(d => d.Package)
                    .WithMany(p => p.SubPackageDetailsPackage)
                    .HasForeignKey(d => d.PackageId)
                    .HasConstraintName("fkey_PackageId");

                entity.HasOne(d => d.PackageNameNavigation)
                    .WithMany(p => p.SubPackageDetailsPackageNameNavigation)
                    .HasPrincipalKey(p => p.PackageName)
                    .HasForeignKey(d => d.PackageName)
                    .HasConstraintName("fkey_PackageName");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasKey(e => e.UserId)
                    .HasName("pk_CustomerId");

                entity.HasIndex(e => e.ContactNo)
                    .HasName("UQ__Users__5C667C05AF286638")
                    .IsUnique();

                entity.HasIndex(e => e.EmailId)
                    .HasName("uq_email")
                    .IsUnique();

                entity.Property(e => e.UserId).ValueGeneratedNever();

                entity.Property(e => e.Address)
                    .HasMaxLength(200)
                    .IsUnicode(false);

                entity.Property(e => e.ContactNo).HasColumnType("numeric(10, 0)");

                entity.Property(e => e.DateOfBirth).HasColumnType("date");

                entity.Property(e => e.EmailId)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsRequired()
                    .HasMaxLength(1)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.LastName)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.UserPassword)
                    .IsRequired()
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.Users)
                    .HasForeignKey(d => d.RoleId)
                    .HasConstraintName("fk_RoleId");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
