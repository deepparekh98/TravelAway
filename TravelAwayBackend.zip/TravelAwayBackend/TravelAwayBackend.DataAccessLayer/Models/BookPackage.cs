﻿using System;
using System.Collections.Generic;

namespace TravelAwayBackend.DataAccessLayer.Models
{
    public partial class BookPackage
    {
        public BookPackage()
        {
            Bookings = new HashSet<Bookings>();
        }

        public long BookingId { get; set; }
        public int? UserId { get; set; }
        public string EmailId { get; set; }
        public byte? PackageId { get; set; }
        public decimal? ContactNo { get; set; }
        public string Address { get; set; }
        public DateTime DateOfTravel { get; set; }
        public short? AdultsCount { get; set; }
        public short? ChildCount { get; set; }
        public decimal? TotalAmount { get; set; }
        public int? SubPackageId { get; set; }
        public string Status { get; set; }

        public virtual Users Email { get; set; }
        public virtual PackageDetails Package { get; set; }
        public virtual SubPackageDetails SubPackage { get; set; }
        public virtual Users User { get; set; }
        public virtual ICollection<Bookings> Bookings { get; set; }
    }
}
