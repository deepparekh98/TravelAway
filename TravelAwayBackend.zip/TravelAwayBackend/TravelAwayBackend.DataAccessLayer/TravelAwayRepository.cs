﻿using TravelAwayBackend.DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using Microsoft.EntityFrameworkCore;

namespace TravelAwayBackend.DataAccessLayer
{
    public class TravelAwayRepository
    {
        TravelAwayDBTestContext context;
        public TravelAwayRepository()
        {
            context = new TravelAwayDBTestContext();
        }
        public TravelAwayRepository(TravelAwayDBTestContext _context)
        {
            context = _context;
        }
        public List<Users> GetAllUsers()
        {
            var lst = (from user in context.Users select user).ToList();
            return lst;
        }

        public List<PackageDetails> GetAllPackages()
        {
            List<PackageDetails> lst = null;
            try
            {
                lst = (from package in context.PackageDetails select package).ToList();
            }
            catch (Exception)
            {
                lst = null;
            }

            return lst;
        }

        public List<BookPackage> GetBookingsBoDate(int s)
        {
            List<BookPackage> lst = null;
            try
            {
                lst = (from x in context.BookPackage where x.DateOfTravel.Month == s select x).ToList();

            }
            catch (Exception)
            {
                lst = null;
            }
            return lst;
        }
        public List<BookPackage> GetAllBookings()
        {
            List<BookPackage> lst = null;
            try
            {
                lst = (from x in context.BookPackage select x).ToList();
            }
            catch (Exception)
            {
                lst = null;
            }
            return lst;
        }

        public List<SubPackageDetails> GetAllPackagesById(string pack)
        {
            List<SubPackageDetails> lst = null;
            try
            {
                lst = (from package in context.SubPackageDetails where package.PackageName == pack select package).ToList();
            }
            catch (Exception)
            {
                lst = null;
            }

            return lst;
        }

        public List<BookPackage> GetAllBookingsByMail(string mail)
        {
            List<BookPackage> lst = null;
            try
            {
                lst = (from x in context.BookPackage where x.EmailId == mail select x).ToList();

            }
            catch (Exception)
            {

                lst = null;
            }
            return lst;
        }

        public List<PackageCategory> GetAllPackageCategories()
        {
            List<PackageCategory> lst = null;
            try
            {
                lst = (from cat in context.PackageCategory select cat).ToList();
            }
            catch (Exception)
            {
                lst = null;
            }

            return lst;
        }

        public bool UpdateStatus(int bookid)
        {
            bool status = false;
            try
            {
                var x = (from y in context.BookPackage where y.BookingId == bookid select y).FirstOrDefault();
                x.Status = "Booking Successful";
                //for decreasing count of packages available for particular PackageCategoryId
                var count = (from z in context.PackageCategory
                             where z.PackageCategoryId == (from q in context.PackageDetails
                                                           where q.PackageId == (from a in context.BookPackage
                                                                                 where a.BookingId == bookid
                                                                                 select a.PackageId).FirstOrDefault()
                                                           select q.PackageCategoryId).FirstOrDefault()
                             select z).FirstOrDefault();

                count.PackagesAvailable = (byte)(((int)count.PackagesAvailable) - 1);
                var bookcount = (from id in context.PackageDetails
                                 where id.PackageId ==
(from ab in context.BookPackage
 where ab.BookingId == bookid
 select ab.PackageId).FirstOrDefault()
                                 select id).FirstOrDefault();

                bookcount.BookingsCount = bookcount.BookingsCount + 1;
                context.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
        public int ValidateUser(string email, string pwd)
        {
            int rid = 0;
            try
            {
                rid = (byte)(from user in context.Users where user.EmailId == email && user.UserPassword == pwd select user.RoleId).FirstOrDefault();
            }
            catch (Exception)
            {
                rid = 0;
            }
            return rid;
        }

        public bool RegisterUser(Users obj)
        {
            // bool status;
            bool s = false;
            try
            {
                var a = (from z in context.Users where z.EmailId == obj.EmailId select z).FirstOrDefault();
                var b = (from z in context.Users where z.ContactNo == obj.ContactNo select z).FirstOrDefault();
                if ((a == null && b == null) && (obj.EmailId != null && obj.UserPassword != null && obj.ContactNo != 0))
                {
                    obj.RoleId = 2;
                    obj.UserId = (from x in context.Users select x.UserId).Max() + 1;
                    context.Users.Add(obj);
                    context.SaveChanges();
                    s = true;
                    return s;
                }
                else
                {
                    s = false;
                }
            }
            catch (Exception e)
            {
                s = false;
            }

            return s;
        }

        public bool AddSubPackage(SubPackageDetails obj)
        {
            // bool status;
            bool s = false;
            try
            {
                obj.SubPackageId = (from x in context.SubPackageDetails select x.SubPackageId).Max() + 1;
                context.SubPackageDetails.Add(obj);
                context.SaveChanges();
                s = true;
            }
            catch (Exception e)
            {
                s = false;
            }

            return s;
        }

        public int BookPackage(BookPackage obj)
        {
            int bookingId = 0;
            try
            {
                obj.BookingId = (from x in context.BookPackage select x.BookingId).Max() + 1;
                bookingId = (int)obj.BookingId;

                obj.PackageId = (from x in context.SubPackageDetails where x.SubPackageId == obj.SubPackageId select x.PackageId).FirstOrDefault();
                obj.UserId = (from x in context.Users where x.EmailId == obj.EmailId select x.UserId).FirstOrDefault();
                obj.TotalAmount = (from x in context.SubPackageDetails where x.SubPackageId == obj.SubPackageId select ((obj.AdultsCount * x.PricePerAdult) + (obj.ChildCount * x.PricePerChild))).FirstOrDefault();
                obj.Status = "Payment Pending";
                context.BookPackage.Add(obj);
                context.SaveChanges();
            }
            catch (Exception)
            {
                bookingId = 0;
            }
            return bookingId;
        }

        public List<BookPackage> DisplayBookingDetailsByCustomer(int userId)
        {
            List<BookPackage> BookingDetails = null;
            try
            {
                BookingDetails = (from x in context.BookPackage where x.UserId == userId select x).ToList<BookPackage>();

                if (BookingDetails == null)
                {
                    Console.WriteLine("Bye");
                }

                /*context.BookPackage.Include(x => x.PackageId).Where(x => x.UserId == userId).OrderByDescending(x => x.DateOfTravel).Select(x => x).ToList<BookPackage>();*/
            }
            catch (Exception ex)
            {
                BookingDetails = null;
            }
            return BookingDetails;
        }

    }
}
